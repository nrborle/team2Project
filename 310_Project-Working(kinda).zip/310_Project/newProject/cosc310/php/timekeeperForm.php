<section id="timekeeper">
<h1>Timekeeper Form</h1>
<div style="overflow-x:auto;">
<table style="width:750px">
  <tr>
    <th rowspan="3">Speaker</th>
    <th colspan="2">Prepared Speech</th>
    <th colspan="2">Impromtu speech table</th>
  </tr>
  <tr>
    <th colspan="2">Duration</th>
    <th colspan="2">Duration</th>
  </tr>
  <tr>
    <th>min</th>
    <th>sec</th>
    <th>min</th>
    <th>sec</th>
  </tr>
  <!-- <form action="/wherever the wind blows.abc"> -->
    <tr>
      <td>1.</td>
      <td><input type="text" name="1_p_min" id="r1c1"></td>
      <td><input type="text" name="1_p_sec" id="r1c2"></td>

      <td><input type="text" name="1_i_min" id="r1c3"></td>
      <td><input type="text" name="1_i_sec" id="r1c4"></td>
    </tr>
    <tr>
      <td>2.</td>
      <td><input type="text" name="2_p_min" id="r2c1"></td>
      <td><input type="text" name="2_p_sec" id="r2c2"></td>

      <td><input type="text" name="2_i_min" id="r2c3"></td>
      <td><input type="text" name="2_i_sec" id="r2c4"></td>
    </tr>
    <tr>
      <td>3.</td>
      <td><input type="text" name="3_p_min" id="r3c1"></td>
      <td><input type="text" name="3_p_sec" id="r3c2"></td>

      <td><input type="text" name="3_i_min" id="r3c3"></td>
      <td><input type="text" name="3_i_sec" id="r3c4"></td>
    </tr>
    <tr>
      <td>4.</td>
      <td><input type="text" name="4_p_min" id="r4c1"></td>
      <td><input type="text" name="4_p_sec" id="r4c2"></td>

      <td><input type="text" name="4_i_min" id="r4c3"></td>
      <td><input type="text" name="4_i_sec" id="r4c4"></td>
    </tr>
    <tr>
      <td>5.</td>
      <td><input type="text" name="5_p_min" id="r5c1"></td>
      <td><input type="text" name="5_p_sec" id="r5c2"></td>

      <td><input type="text" name="5_i_min" id="r5c3"></td>
      <td><input type="text" name="5_i_sec" id="r5c4"></td>
    </tr>
    <tr>
      <td>6.</td>
      <td><input type="text" name="6_p_min" id="r6c1"></td>
      <td><input type="text" name="6_p_sec" id="r6c2"></td>

      <td><input type="text" name="6_i_min" id="r6c3"></td>
      <td><input type="text" name="6_i_sec" id="r6c4"></td>
    </tr>
    <tr>
      <td>1.</td>
      <td><input type="text" name="7_p_min" id="r7c1"></td>
      <td><input type="text" name="7_p_sec" id="r7c2"></td>

      <td><input type="text" name="7_i_min" id="r7c3"></td>
      <td><input type="text" name="7_i_sec" id="r7c4"></td>
    </tr>
    <tr>
      <td>1.</td>
      <td><input type="text" name="8_p_min" id="r8c1"></td>
      <td><input type="text" name="8_p_sec" id="r8c2"></td>

      <td><input type="text" name="8_i_min" id="r8c3"></td>
      <td><input type="text" name="8_i_sec" id="r8c4"></td>
    </tr>
    <tr>
      <td>9.</td>
      <td><input type="text" name="9_p_min" id="r9c1"></td>
      <td><input type="text" name="9_p_sec" id="r9c2"></td>

      <td><input type="text" name="9_i_min" id="r9c3"></td>
      <td><input type="text" name="9_i_sec" id="r9c4"></td>
    </tr>
    <tr>
      <td>10.</td>
      <td><input type="text" name="10_p_min" id="r10c1"></td>
      <td><input type="text" name="10_p_sec" id="r10c2"></td>

      <td><input type="text" name="10_i_min" id="r10c3"></td>
      <td><input type="text" name="10_i_sec" id="r10c4"></td>
    </tr>
    <tr>
      <td>11.</td>
      <td><input type="text" name="11_p_min" id="r11c1"></td>
      <td><input type="text" name="11_p_sec" id="r11c2"></td>

      <td><input type="text" name="11_i_min" id="r11c3"></td>
      <td><input type="text" name="11_i_sec" id="r11c4"></td>
    </tr>
    <tr>
      <td>12.</td>
      <td><input type="text" name="12_p_min" id="r12c1"></td>
      <td><input type="text" name="12_p_sec" id="r12c2"></td>

      <td><input type="text" name="12_i_min" id="r12c3"></td>
      <td><input type="text" name="12_i_sec" id="r12c4"></td>
    </tr>
    <tr>
      <td>13.</td>
      <td><input type="text" name="13_p_min" id="r13c1"></td>
      <td><input type="text" name="13_p_sec" id="r13c2"></td>

      <td><input type="text" name="13_i_min" id="r13c3"></td>
      <td><input type="text" name="13_i_sec" id="r13c4"></td>
    </tr>
    <tr>
      <td>14.</td>
      <td><input type="text" name="14_p_min" id="r14c1"></td>
      <td><input type="text" name="14_p_sec" id="r14c2"></td>

      <td><input type="text" name="14_i_min" id="r14c3"></td>
      <td><input type="text" name="14_i_sec" id="r14c4"></td>
    </tr>
    <tr>
      <td>15.</td>
      <td><input type="text" name="15_p_min" id="r15c1"></td>
      <td><input type="text" name="15_p_sec" id="r15c2"></td>

      <td><input type="text" name="15_i_min" id="r15c3"></td>
      <td><input type="text" name="15_i_sec" id="r15c4"></td>
    </tr>
    <tr>
      <!-- <td><input type="submit" value="Submit"></td> -->
    </tr>
  <!-- </form> -->
</table>
</div>
</section>

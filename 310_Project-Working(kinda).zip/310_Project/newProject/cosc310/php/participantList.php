<section id="speakers">
 <!-- <form method="post" action="php/getParticipantList.php"> -->
   <table>
      <thead><tr><th>Participant List</th></tr></thead>
      <tbody>
		<tr><td>1</td><td><input type="text" name="P1"></td></tr>
		<tr><td>2</td><td><input type="text" name="P2"></td></tr>
		<tr><td>3</td><td><input type="text" name="P3"></td></tr>
		<tr><td>4</td><td><input type="text" name="P4"></td></tr>
		<tr><td>5</td><td><input type="text" name="P5"></td></tr>
		<tr><td>6</td><td><input type="text" name="P6"></td></tr>
		<tr><td>7</td><td><input type="text" name="P7"></td></tr>
		<tr><td>8</td><td><input type="text" name="P8"></td></tr>
		<tr><td>9</td><td><input type="text" name="P9"></td></tr>
		<tr><td>10</td><td><input type="text" name="P10"></td></tr>
		<tr><td>11</td><td><input type="text" name="P11"></td></tr>
		<tr><td>12</td><td><input type="text" name="P12"></td></tr>
		<tr><td>13</td><td><input type="text" name="P13"></td></tr>
		<tr><td>14</td><td><input type="text" name="P14"></td></tr>
		<tr><td>15</td><td><input type="text" name="P15"></td></tr>
     </tbody>
   </table>
 <!-- </form> -->
</section>

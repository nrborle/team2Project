Jumbo Shrimp
COSC 310 Project

Calculation application for public speaking competition.

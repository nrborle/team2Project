package Project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class FormGenerator {
	
	static String[] mainCategories = {"Introduction", "Body of Speech", "Conclusion", "Delivery and Style"};
	static String[] introductionCriteria = {"Aroused interest", "Effective and appropriate presentation"};
	static String[] BoSCriteria = {"Information complete & logically presented", "Knowledgeable about the subject", "Speech developed with originality", "Proper and effective use of language", "Kept to topic", "Correct grammar"};
	static String[] conclusionCriteria = {"Left audience with an appreciation of topic", "Sums up material", "Logical: a capsule of what has been said"};
	static String[] DaSCriteria = {"Spoke to audience with enthusiasm, confidence and eye contact", "Rate of delivery", "Proper stance, audible, correct pronunciation & enunciation"};
	
	static ArrayList<String[]> criteriaList = new ArrayList<>();
	
	static File start = new File("htmlStart.txt");
	static File end = new File("htmlEnd.txt");
	
	static String trStart = "<tr>";
	static String trEnd = "</tr>";
	static String thStart = "<th colspan= \"16\">";
	static String thEnd = "</th>";
	static String tdStart = "<td>";
	static String tdEnd = "</td>";
	static String headStart = "<h4>";
	static String headEnd = "</h4>";
	static String tableStart = "<table>";
	static String tableEnd = "</table>";
	static String tab2 = "\t\t";
	static String tab3 = "\t\t\t";
	static String tab4 = "\t\t\t\t";
	static String tab5 = "\t\t\t\t\t";
	
	public static void main(String[] args) throws IOException{
		
		
		makeForm();
		
	}
	
	
	public static void makeForm() throws IOException{
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("File name: ");
		String fn = input.next();
		System.out.println("File extension: ");
		String fe = input.next();
		System.out.println("Judge Number: ");
		int jn = input.nextInt();
		
		File target = makeFile(fn, fe);
		
		input.close();
		
		Boolean fileExists = !target.createNewFile();
		
		System.out.println(fileExists);

		while(fileExists){
			
			target.delete();
			target = makeFile(fn, fe);
			fileExists = !target.createNewFile();
			
		}
		
//		writeText(target, start);
		String[] formIDs = {"psJ"+jn, "isJ"+jn};
		htmlFormGenerate(target, start, end, formIDs, masterListGenerate());
//		writeText(target, end);
		System.out.println("Success!");
	
	}
	
	public static File makeFile(String name, String extension){
		
		File target = new File(name + "." + extension);
		
		return target;
		
	}
	
	
//	public static void writeText(File target, File text) throws FileNotFoundException{
//		PrintWriter out2 = new PrintWriter(target);
//		Scanner end = new Scanner(text);
//		
//		while(end.hasNextLine()){
//			out2.println(end.nextLine());
//		}
//		
//		out2.close();
//		end.close();
//	}
	
	public static void htmlFormGenerate(File target, File HTMLStart, File HTMLEnd, String[] formIDs, ArrayList<CategoryObj> masterList) throws FileNotFoundException{
		
		PrintWriter out = new PrintWriter(target);
		Scanner start = new Scanner(HTMLStart);
		Scanner end = new Scanner(HTMLEnd);
		
		while(start.hasNextLine()){
			out.println(start.nextLine());
		}
		for(int formCounter=0; formCounter<formIDs.length; formCounter++){
			
		if(formCounter ==0){
			out.println("<h2>Prepared Speech</h2>");
		}else{
			out.println("<h2>Impromptu Speech</h2>");
		}
			
		out.println(tab2 + "<form id = \"" + formIDs[formCounter] + "\" method=\"post\" action=\"Some javascript that doesn't exist yet :(\">");
		
		for(CategoryObj catObj: masterList){
			
//			
//			String[] tempArr = catObj.getCategoryCriteria();
//			
//			out.println(tab4 + tableStart);
//			for(int i=0; i<tempArr.length; i++){
//				
//				out.print(tab5 + thStart);
//				out.print(tempArr[i]);
//				out.println(thEnd);
//				
//			}
//			out.println(tab4 + tableEnd);
			
			//printing headers
			out.print(tab3 + headStart);
			out.print(catObj.getCategoryName());
			out.println(headEnd);
			
			//printing judging criteria followed by drop down boxes in a table
			String[] tempArr = catObj.getCategoryCriteria();
			int rowCounter = 1;
			for(int i=0; i<tempArr.length; i++){
				
			out.println(tab3 + tableStart);
			out.println(tab4 + trStart);
		
			out.print(tab5 + tdStart);
			out.print(tempArr[i]);
			out.println(tdEnd);
			
			
			for(int j = 1; j<16; j++){
				
				out.print(tab5 + tdStart);
				
				out.print("<select name=\"R" +  rowCounter + "C" + j + "\">");
				for(int k = 1; k<11; k++)
				out.print("<option value =\"" + k + "\">" + k + "</option>");
				
				out.print("</select>");
				out.println(tdEnd);
				
			}
			
			rowCounter++;
			out.println(tab4 + trEnd);
			out.println(tab3 + tableEnd);
			}			
		}
		out.println(tab2 + "</form>");
		
		}
		while(end.hasNextLine()){
			out.println(end.nextLine());
		}
		
		out.close();
		start.close();
		end.close();
	}
	
	
	public static ArrayList<CategoryObj> masterListGenerate(){
		
		ArrayList<CategoryObj> masterList = new ArrayList<>();
		criteriaList.add(introductionCriteria);
		criteriaList.add(BoSCriteria);
		criteriaList.add(conclusionCriteria);
		criteriaList.add(DaSCriteria);
		
		
		for(int i=0; i<mainCategories.length; i++){
			CategoryObj temp = new CategoryObj();
			
			temp.setCategoryName(mainCategories[i]);
			temp.setCategoryCriteria(criteriaList.get(i));
			
			masterList.add(temp);
			
		}
		
		return masterList;
		
	}
	
}
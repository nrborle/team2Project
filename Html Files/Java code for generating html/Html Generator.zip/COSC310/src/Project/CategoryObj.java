package Project;

public class CategoryObj {
	
	String catName;
	String[] catCriteria;
	
//	public CategoryObj(String CategoryName, String[] CategoryCriteria){
//		
//		catName = CategoryName;
//		catCriteria = CategoryCriteria;
//		
//	}
	
	public String getCategoryName(){
		
		return catName;
		
	}
	
	public String[] getCategoryCriteria(){
		
		return catCriteria;
		
	}
	
	public void setCategoryName(String CategoryName){
		
		catName = CategoryName;
		
	}
	
	public void setCategoryCriteria(String[] CategoryCriteria){
		
		catCriteria = CategoryCriteria;
		
	}
}
